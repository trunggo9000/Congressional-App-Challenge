setScreen("LogIn");
var curbal = [];
var totalAccts=[];
var user;
var pass;

onEvent("saveAcct", "click", function() {
  var username = getText("createUserInput");
  var password = getText("createPassInput");
  if ((username === "") && (password === "")) {
    showElement("alert2");
  } else {
  appendItem(totalAccts, username + " " + password + " ");
  console.log(("Username: " + username) + " Password: " + password);
  console.log(totalAccts);
  setScreen("LogIn");
  }
});

onEvent("makeAcct", "click", function(){
  setScreen("CreateAcct");
  setText("createUserInput", "");
  setText("createPassInput", "");
  setText("userInput", "");
  setText("passInput", "");
  hideElement("alert");
});

onEvent("login", "click", function(){
  user = getText("userInput");
  pass = getText("passInput");
  loginCheck();
});

onEvent("skipLogin", "click", function( ) {
  setScreen("HomeScreen");
});


onEvent("logout", "click", function(){
  logoutCheck();
  console.log(totalAccts);
  setScreen("LogIn");
});

onEvent("goBack", "click", function() {
  setScreen("LogIn");
});

function loginCheck() {
  if ((user === "") && (pass === "")) {
    showElement("alert");
  }
  var i = -1;
  while (i < totalAccts.length) {
    i++;
    if (totalAccts[i] === (user + " " + pass + " ")) {
        setScreen("HomeScreen");
    } else {
        for (var a = 0; a < curbal.length; a++) {
        if (totalAccts[i] === (user + " " + pass + " " + curbal[a])) {
          setScreen("HomeScreen");
          console.log(curbal[a]);
        }
      } 
    }
    if (totalAccts[i] != (user + " " + pass + " ")) {
      showElement("alert");
    }
  }
}

function logoutCheck() {
  var i = -1;
  while (i < totalAccts.length) {
    i++;
    if (totalAccts[i] === (user + " " + pass + " ")) {
        totalAccts[i] = user + " " + pass + " " + getNumber("balance");
        appendItem(curbal, getNumber("balance"));
        console.log(curbal);
        console.log(totalAccts[i]);
      } else {
          for (var a = 0; a < curbal.length; a++) {
          if (totalAccts[i] === (user + " " + pass + " " + curbal[a])) {
            curbal[a] = getNumber("balance");
            totalAccts[i] = user + " " + pass + " " + curbal[a];
        }
      }
    }
  }
  reset();
}

function reset() {
  hideElement("alert");
  setText("userInput", "");
  setText("passInput", "");
}

//used for setting text box Id"s
var xOne = 0;
var xTwo = 6;
var xThree = 13;
//used for evaluating number of text boxes
var z = 0;
//used to keep track of how many have been removed
var yOne = 0;
var yTwo = 6;
var yThree = 13;
//used to ensure after returning to a previous page if you remove a box and then add another it does not overlap
var numBoxesPgTwo = 0;
//Same as previous for page 3
var numBoxesPgThree = 0;
//used to displace future text boxes to aviod overlap
var Displacer = 0;
//used to keep track of current boxes
var numBoxesPgOne = 0;

//Adding Events
onEvent("Add_College_Button", "click", function( ) {
  if (z === 0) {
    //Creates textbox in position below College button and displayes used slots
    textInput("collegeName" + xOne, "College Name");
    setPosition("collegeName" + xOne, 10, 160, 150, 30);
    textInput("Deadline" + xOne, "Deadline");
    setPosition("Deadline" + xOne, 150, 160, 75, 30);
    dropdown("Dropdown" + xOne, "Status", "Not Started", "Working on", "Submitted");
    setPosition("Dropdown" + xOne, 225, 160, 110, 30);
    setText("CollegeOne", "College List: " + (z + 1) + "/15");
    setText("CollegeTwo", "College List: " + (z + 1) + "/15");
    setText("CollegeThree", "College List: " + (z + 1) + "/15");
    //increases values of x, z, and the displacer and logs this information
    xOne++;
    z++;
    Displacer = 0;
    Displacer++;
    numBoxesPgOne++;
    console.log("xOne = " + xOne);
    console.log("z = " + z);
  } else {
    //creates a displaced text box on pg. 1 as long as z < 5
    if (z < 5) {
          var Displacement = 50 * Displacer;
          textInput("collegeName" + xOne, "College Name");
          setPosition("collegeName" + xOne, 10, 160 + Displacement, 150, 30);
          textInput("Deadline" + xOne, "Deadline");
          setPosition("Deadline" + xOne, 150, 160 + Displacement, 75, 30);
          dropdown("Dropdown" + xOne, "Status", "Not Started", "Working on", "Submitted");
          setPosition("Dropdown" + xOne, 225, 160 + Displacement, 110, 30);
          xOne++;
          z++;
          //Changes number of open slots
          setText("CollegeOne", "College List: " + z + "/15");
          setText("CollegeTwo", "College List: " + z + "/15");
          setText("CollegeThree", "College List: " + z + "/15");
          //increases displacer and logs x and z values
          Displacer++;
          numBoxesPgOne++;
          console.log("xOne = " + xOne);
          console.log("z = " + z);
        } else {
          //moves to second screen, resets displacer, and creates a text box at the top
          setScreen("CollegeScreenTwo");
          Displacer = 0;
          console.log("Displacer = " + Displacer);
          if (z === 5) {
                textInput("collegeName" + xTwo, "College Name");
                setPosition("collegeName" + xTwo, 10, 160, 150, 30);
                textInput("Deadline" + xTwo, "Deadline");
                setPosition("Deadline" + xTwo, 150, 160, 75, 30);
                dropdown("Dropdown" + xTwo, "Status", "Not Started", "Working on", "Submitted");
                setPosition("Dropdown" + xTwo, 225, 160, 110, 30);
                
    xTwo++;
    z++;
    numBoxesPgTwo++;
    //reduces number of open slots
    setText("CollegeOne", "College List: " + z + "/15");
    setText("CollegeTwo", "College List: " + z + "/15");
    setText("CollegeThree", "College List: " + z + "/15");
   //increases displacer for future boxes and logs information
    Displacer++;
    console.log("Displacer " + Displacer);
    console.log("xTwo = " + xTwo);
    console.log("z = " + z);
    console.log("num boxes 2 " + numBoxesPgTwo);
          } else {
            //used when returning from page one after navigation to avoid overlap of boxes
            Displacer = numBoxesPgTwo;
          }
        }
  }
});
//Adding Events Screen 2
onEvent("AddCollege2", "click", function( ) {
  if (z < 10) {
    var Displacer = numBoxesPgTwo;
    var Displacement2 = 50 * Displacer;
    //Displaces Future Textboxes
    textInput("collegeName" + xTwo, "College Name");
    setPosition("collegeName" + xTwo, 10, 160 + Displacement2, 150, 30);
    textInput("Deadline" + xTwo, "Deadline");
    setPosition("Deadline" + xTwo, 150, 160 + Displacement2, 75, 30);
    dropdown("Dropdown" + xTwo, "Status", "Not Started", "Working on", "Submitted");
    setPosition("Dropdown" + xTwo, 225, 160 + Displacement2, 110, 30 );
    xTwo++;
    z++;
    numBoxesPgTwo++;
    //increases used College slots
    setText("CollegeOne", "College List: " + z + "/15");
    setText("CollegeTwo", "College List: " + z + "/15");
    setText("CollegeThree", "College List: " + z + "/15");
    //logs x and z values
    console.log("xTwo = " + xTwo);
    console.log("z = " + z);
    //increases displacer and logs info
    Displacer++;
    console.log("Displacer = " + Displacer);
    console.log("Boxes 2 = " + numBoxesPgTwo);
  } else {
    //moves to third and final screen, resets displacer, and creates first text box on said screen
    setScreen("CollegeScreenThree");
    Displacer = 0;
    if (z === 10) {
                    textInput("collegeName" + xThree, "College Name");
                    setPosition("collegeName" + xThree, 10, 160, 150, 30);
                    textInput("Deadline" + xThree, "Deadline");
                    setPosition("Deadline" + xThree, 150, 160, 75, 30);
                    dropdown("Dropdown" + xThree, "Status", "Not Started", "Working on", "Submitted");
                    setPosition("Dropdown" + xThree, 225, 160, 110, 30);
                    
    //increases x, z, and displacer values
    xThree++;
    z++;
    //increases used College slots
    setText("CollegeOne", "College List: " + z + "/15");
    setText("CollegeTwo", "College List: " + z + "/15");
    setText("CollegeThree", "College List: " + z + "/15");
    //logs values in console
    console.log("xThree = " + xThree);
    console.log("z = " + z);
    }
  }
});


//Adding Events Screen 3
onEvent("AddCollege3", "click", function( ) {
  if (z < 15) {
    if (z === 11) {
      Displacer = 1;
    }var Displacement3 = 50 * Displacer;
    textInput("collegeName" + xThree, "College Name");
    setPosition("collegeName" + xThree, 10, 160 + Displacement3, 150, 30);
    textInput("Deadline" + xThree, "Deadline");
    setPosition("Deadline" + xThree, 150, 160 + Displacement3, 75, 30);
    dropdown("Dropdown" + xThree, "Status", "Not Started", "Working on", "Submitted");
    setPosition("Dropdown" + xThree, 225, 160 + Displacement3, 110, 30);
    xThree++;
    z++;
    Displacer++;
    setText("CollegeOne", "College List: " + z + "/15");
    setText("CollegeTwo", "College List: " + z + "/15");
    setText("CollegeThree", "College List: " + z + "/15");
    console.log("z = " + z);
    console.log("Displacer = " + Displacer);
    
  } else {
    
  }
});

//Removing top College
onEvent("Remove_College_Button", "click", function( ) {
  if (z > 0 && z < 6) {
    deleteElement("collegeName" + yOne);
    deleteElement("Deadline" + yOne);
    deleteElement("Dropdown" + yOne);
    yOne++;
    z--;
    Displacer--;
    setText("CollegeOne", "College List: " + z + "/15");
    setText("CollegeTwo", "College List: " + z + "/15");
    setText("CollegeThree", "College List: " + z + "/15");
    console.log(z);
    if (numBoxesPgOne <= 5) {
      for (var i = 1; i < xOne; i++) {
          var DisplacementTwo = 50 * (i - yOne);
          setPosition("collegeName" + i, 10, 160 + DisplacementTwo, 150, 30);
          setPosition("Deadline" + i, 150, 160 + DisplacementTwo, 75, 30);
          setPosition("Dropdown" + i, 225, 160 + DisplacementTwo, 110, 30);
          
      }
      numBoxesPgOne--;
    }
    if (xOne >= 6 && z === 0) {
      xOne = 0;
      yOne = 0;
    }
  }
});



//Removing top College Pg. 2
onEvent("RemoveCollegeTwo", "click", function( ) {
  if (z > 5 && z < 11) {
    deleteElement("collegeName" + yTwo);
    deleteElement("Deadline" + yTwo);
    deleteElement("Dropdown" + yTwo);
    yTwo++;
    z--;
    Displacer--;
    setText("CollegeOne", "College List: " + z + "/15");
    setText("CollegeTwo", "College List: " + z + "/15");
    setText("CollegeThree", "College List: " + z + "/15");
    console.log(z);
    if (numBoxesPgTwo <= 5) {
      for (var i = 5; i < xTwo; i++) {
          var DisplacementRemoverTwo = 50 * (i-yTwo);
          setPosition("collegeName" + i, 10, 160 + DisplacementRemoverTwo, 150, 30);
          setPosition("Deadline" + i, 150, 160 + DisplacementRemoverTwo, 75, 30);
          setPosition("Dropdown" + i, 225, 160 + DisplacementRemoverTwo, 110, 30);
      }
      numBoxesPgTwo--;
    }
    if (xTwo >= 12 && z === 5) {
      xTwo = 6;
      yTwo = 6;
    }
    if (z === 5) {
      setScreen("HomeScreen");
    }
  }
});

//Removing top College Pg. 3
onEvent("RemoveCollegeThree", "click", function( ) {
  if (z > 10) {
    deleteElement("collegeName" + yThree);
     deleteElement("Deadline" + yThree);
    deleteElement("Dropdown" + yThree);
    yThree++;
    z--;
    Displacer--;
    setText("CollegeOne", "College List: " + z + "/15");
    setText("CollegeTwo", "College List: " + z + "/15");
    setText("CollegeThree", "College List: " + z + "/15");
    console.log(z);
    if (numBoxesPgThree <= 5) {
      for (var i = 11; i < xThree; i++) {
          var DisplacementRemoverThree = 50 * (i-yThree);
          setPosition("collegeName" + i, 10, 160 + DisplacementRemoverThree, 150, 30);
          setPosition("Deadline" + i, 150, 160 + DisplacementRemoverThree, 75, 30);
          setPosition("Dropdown" + i, 225, 160 + DisplacementRemoverThree, 110, 30);
      }
      numBoxesPgThree--;
    }
    if (xThree >= 16 && z === 10) {
      xThree = 13;
      yThree = 13;
    }
    if (z === 10) {
      setScreen("CollegeScreenTwo");
    }
  }
});

//Navigation Buttons
//TO About Screen:
onEvent("AboutButton", "click", function() {
  setScreen("About");
});
//Return Home From About
onEvent("ReturnButtonAbout", "click", function() {
  setScreen("HomeScreen");
});
//To Research Screen:
onEvent("ResearchButton", "click", function() {
  setScreen("ResearchScreen");
});
//Return Home From Research:
onEvent("ReturnButtonResearch", "click", function(){
  setScreen("HomeScreen");
});
onEvent("research1", "click", function(event) {
  open("https://www.commonapp.org/");
});
onEvent("research2", "click", function(event) {
  open("https://apply.universityofcalifornia.edu/my-application/login");
});
onEvent("research3", "click", function( ) {
  open("https://www.collegeboard.org/");
});
onEvent("research4", "click", function( ) {
  open("https://www.usnews.com/best-colleges/rankings/national-universities");
});
onEvent("ReturnButtonAbout", "click", function(event) {
  console.log("ReturnButtonAbout clicked!");
});
//returns to home screen from screen two
onEvent("PreviousScreenOne", "click", function( ) {
  setScreen("HomeScreen");
});
//returns to screen two from screen three
onEvent("PreviousScreenTwo", "click", function( ) {
  setScreen("CollegeScreenTwo");
});
//goes to screen two from screen one
onEvent("NextPageOne", "click", function( ) {
  setScreen("CollegeScreenTwo");
});
//goes to screen three from screen two
onEvent("NextButtonTwo", "click", function( ) {
  setScreen("CollegeScreenThree");
});
onEvent("research4", "click", function(event) {
  console.log("research4 clicked!");
});



